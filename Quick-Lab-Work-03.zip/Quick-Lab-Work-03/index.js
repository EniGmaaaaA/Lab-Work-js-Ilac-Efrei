import data from './data/MOCK_DATA.json' assert { type: 'json' };
import express from 'express';

console.log(data);

const app = express();
const port = 3000;

app.route('/book')
    .get((req, res) => {
        res.send("<p>"+JSON.stringify(data)+"</p>");
    })
    .post((req, res) => {
        res.send('Add a book')
    })
    .put((req, res) => {
        res.send('Update the book')
    })


// http://localhost:3000/members/28/age/47    
app.get("/members/:memberId/age/:age", (req, res) => {
    // Output: { memberId: '28', age: '47' }
    const memberId = Number(req.params.memberId);
    const memberAge = Number(req.params.age);
    res.send(`Member ID: ${memberId} <br> Member Age: ${memberAge}`);
});

// http://localhost:3000/workers/12
app.get("/workers/:id/", (req, res) => {
    const workerId = Number(req.params.id);
    const worker = data.filter((element) => element.id === workerId);
    res.send(worker); // the same result/output as above
});


app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});